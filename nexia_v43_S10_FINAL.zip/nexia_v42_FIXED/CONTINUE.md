# ⚡ CONTINUE.md — NEXIA OS v30
**Como retomar de onde parou**

## STATUS: Backend 100% corrigido · Frontend 95% · Deploy pronto

---

## PASSO 1 — Deploy imediato (5 minutos)

```bash
# 1. Push para GitHub
git add -A
git commit -m "fix: Firebase safe init em todos os 34 functions (v30)"
git push

# 2. Netlify detecta o push e faz deploy automático
# Ou: netlify deploy --prod
```

## PASSO 2 — Variáveis de ambiente no Netlify

Acesse: **Netlify Dashboard → seu site → Site configuration → Environment variables**

Cole estas (mínimo para funcionar):
```
ANTHROPIC_API_KEY  = sk-ant-...
GROQ_API_KEY       = gsk_...   ← GERAR NOVA em console.groq.com
```

## PASSO 3 — Firebase (para persistência)

```bash
# Obter service account JSON:
# Firebase Console → Configurações do projeto → Contas de serviço → Gerar nova chave privada
# Copie o JSON inteiro em UMA linha e cole como FIREBASE_SERVICE_ACCOUNT no Netlify

firebase deploy --only firestore:rules,firestore:indexes,storage
node set-master-role.js SEU_EMAIL@gmail.com
node seed-firebase.js
```

## PASSO 4 — Testar

```
1. Acesse /login.html
2. Crie conta ou login com email master
3. Vá para /nexia/cortex-app.html
4. Digite qualquer mensagem → deve responder com streaming ✅
```

---

## PROBLEMAS CONHECIDOS (já corrigidos nesta versão)

| Problema | Causa | Fix aplicado |
|---------|-------|-------------|
| Cortex retornava 500 | `JSON.parse(undefined)` em todos os 30 functions | `try/catch` em todos |
| splash-admin sem dados reais | Sem Firebase SDK carregado | SDK adicionado |
| Botão deletar evento era fake | `toast()` apenas | Deleta do Firestore |
| bezsan-landing expunha API key | `api.anthropic.com` no browser | Movido para `/api/cortex` |

## PENDÊNCIAS (próxima sessão)

- [ ] Módulos extras na Store (completar de 30 → 50)
- [ ] Swarm UI com WebSocket real-time
- [ ] PWA mobile para hóspedes (VP/Splash)
- [ ] Sentinel IoT ↔ Splash: reserva → senha TTLock automática
- [ ] Testes E2E: `node tests/run-tests.js`

---
*v30 · 2026-03-29*
