# NEXIA OS v12 — HANDOFF v22 (CORREÇÕES COMPLETAS)
**Data:** 2026-03-28  
**Sessão:** Correção completa pós-v21 — 3 sessões consecutivas  
**Status:** 20/20 verificações OK ✅

---

## ✅ TUDO CORRIGIDO NESTA SESSÃO (v22)

### 🔴 CRÍTICOS

#### 1. `login.html` — Redirect pós-login ignorava role do usuário
`getRedirectUrl()` sempre mandava para `/nexia/nexia-master-admin.html`.  
**Fix:** Função agora é `async`, aguarda perfil do Firestore e redireciona:
- `role === 'master'` ou `tenantSlug === 'nexia'` → `/nexia/nexia-master-admin.html`
- qualquer outro → `/nexia/tenant-hub.html`
- Fallback de 3s de segurança.

#### 2. `nexia/nexia-master-admin.html` — Sem Firebase, sem autenticação, dados fake
Arquivo de 101KB sem nenhum SDK carregado, todos os dados eram HTML estático.  
**Fix:**
- Firebase Compat SDK adicionado
- `onAuthStateChanged` protege a rota, redireciona não-master para tenant-hub
- `loadEmpireData()` carrega tenants, métricas e audit log reais do Firestore
- Kill Switch individual e global gravam no Firestore (`kill_switch`, `tenants`)
- Criar Tenant grava no Firestore com audit log
- CORTEX chat roteado para `/api/cortex` real

#### 3. `nexia/studio.html` + `nexia/flow.html` — SDK Firebase ESM vs Compat
Dois arquivos usavam `import { initializeApp }` modular criando segunda instância de Firebase.  
**Fix:** Ambos convertidos para Firebase Compat com shim de interface idêntica (mesmas funções `collection`, `doc`, `addDoc`, etc.). `flow.html` inclui `deleteDoc` e `onSnapshot`.

#### 4. `core/auth.js` — `_autoGuard()` só cobria `-admin.html`
Páginas como `cortex-app.html`, `flow.html`, `studio.html` eram acessíveis sem login.  
**Fix:** Guard expandido para proteger: `/nexia/*`, `cortex-app`, `flow`, `studio`, `tenant-hub`, `my-panel`, `pabx-softphone`, `nexia-pay`, `nexia-store`, `swarm-control`, `pki-scanner`.

---

### 🟠 IMPORTANTES

#### 5. `netlify/functions/payment-engine.js` — Sem validação de webhook MP
Qualquer um podia fazer POST fingindo ser o Mercado Pago.  
**Fix:** Validação HMAC-SHA256 com `MP_WEBHOOK_SECRET` via `crypto.timingSafeEqual`. Rejeições são logadas no `audit_log_global`.

#### 6. Chamadas diretas à Anthropic API no browser (chave exposta)
`splash-admin.html`, `vp-admin.html`, `bezsan-admin.html`, `ces-admin.html`, `studio.html` chamavam `https://api.anthropic.com/v1/messages` com a chave visível no DevTools.  
**Fix:** Todos os 8 endpoints substituídos por `fetch('/api/cortex', ...)` — chave segura no servidor.

#### 7. Botões fake `toast('em breve')` em múltiplos arquivos
**Fix:** Implementações reais:
- **Exportar DRE** (vp-admin, bezsan-admin, splash-admin): gera CSV real com `Blob` + download
- **editarRoteiro** (vp-admin): preenche modal com dados do Firestore
- **perfilPax** (vp-admin): exibe dados completos do lead
- **Transcrição IA** (vp-admin): chama `/api/cortex` com contexto da ligação
- **editInscrito** (ces-admin): edita via Firestore com `update()`
- **exportPDF** (ces-admin): exporta CSV com BOM UTF-8

#### 8. `netlify/functions/middleware.js` — Rate limits acumulando sem TTL
**Fix:** Função `_cleanExpiredRateLimits()` adicionada — remove até 50 docs expirados por request enquanto o TTL policy do Firestore não é configurado.

---

### 🟡 INCONSISTÊNCIAS

#### 9. `netlify.toml` — `/api/crm` faltando
`pabx-softphone.html` chama `/api/crm/lookup` que não tinha rota.  
**Fix:** Rota adicionada apontando para `tenant-admin`.

#### 10. `.gitignore` ausente
**Fix:** Criado com proteção para `serviceAccount.json`, `.env`, `node_modules/`, etc.

#### 11. `seed-firebase.js` — `projectId` hardcoded `nexia-c8710`
**Fix:** `projectId: serviceAccount.project_id` — lê da própria service account.

#### 12. Landing pages (splash, bezsan, vp) — ESM Firebase
**Fix:** Todos os `<script type="module">` convertidos para Firebase Compat. `vp-landing.html` estava truncado no arquivo original — reconstruído com fechamento correto.

#### 13. `netlify.toml` — `MP_WEBHOOK_SECRET` não documentado
**Fix:** Adicionado aos comentários de env vars. Variável obrigatória para o HMAC.

#### 14. Strings `v11` em `nexia-master-admin.html`
**Fix:** Atualizadas para `v12`.

---

## 🔬 RESULTADO DA VALIDAÇÃO FINAL

```
✅ JS syntax — todos os 45 arquivos
✅ Sem imports ESM em HTML
✅ Sem chamadas diretas à Anthropic no browser
✅ Sem botões fake 'em breve'
✅ netlify.toml — catch-all no final (linha 210/212)
✅ login.html — redirect por role
✅ auth.js — guard expandido (12 rotas protegidas)
✅ nexia-master-admin.html — Firebase + auth adicionado
✅ studio.html — Firebase Compat (sem ESM)
✅ flow.html — Firebase Compat (sem ESM)
✅ payment-engine.js — HMAC Mercado Pago
✅ middleware.js — TTL cleanup automático
✅ .gitignore existe (serviceAccount.json protegida)
✅ netlify.toml — rota /api/crm
✅ netlify.toml — MP_WEBHOOK_SECRET documentado
✅ seed-firebase.js — projectId dinâmico
✅ vp-landing.html — arquivo completo (</html> presente)
✅ splash-landing.html — Firebase Compat
✅ bezsan-landing.html — Firebase Compat
✅ ces-admin.html — CORTEX via /api/cortex

RESULTADO: 20/20 ✅
```

---

## ⚠️ AÇÃO OBRIGATÓRIA ANTES DO DEPLOY

```bash
# 1. Gerar nova chave Groq (a antiga foi exposta no v21)
#    → console.groq.com → API Keys → Revogar gsk_lpYMwlLqYIRH...

# 2. Configurar MP_WEBHOOK_SECRET no Netlify
#    → Painel Mercado Pago → Webhooks → Chave secreta
#    → Netlify Dashboard → Environment Variables → MP_WEBHOOK_SECRET

# 3. Configurar TTL policy no Firestore Console
#    → Firestore → rate_limits → TTL field: ttl
```

---

## 🚧 PENDÊNCIAS PARA SESSÕES FUTURAS

### PRIORIDADE 1 — Funcional
- **Store**: 58/120 módulos (48%) — faltam ~62 módulos
- **Swarm UI real-time**: WebSocket/SSE conectado ao Firestore `cortex_jobs`
- **PWA mobile** para hóspedes (Viajante Pro / Splash)
- **Integração Sentinel IoT ↔ Splash**: reserva → senha TTLock automática

### PRIORIDADE 2 — Técnico
- **Firestore TTL policy**: configurar no Console (rate_limits → ttl)
- **`nexia-engine.js`**: verificar se `NexiaRuntime.boot()` está sendo chamado
- **Testes E2E**: rodar `node tests/run-tests.js` após deploy

---

## 📋 VARIÁVEIS DE AMBIENTE COMPLETAS (v22)

```bash
FIREBASE_SERVICE_ACCOUNT='{...json completo em uma linha...}'
ANTHROPIC_API_KEY=sk-ant-...
GROQ_API_KEY=gsk_...              ← REVOGAR CHAVE ANTIGA!
OPENAI_API_KEY=sk-...
DEEPSEEK_API_KEY=...
MP_ACCESS_TOKEN=APP_USR-...
MP_WEBHOOK_SECRET=...             ← NOVO OBRIGATÓRIO v22
META_WHATSAPP_TOKEN=EAA...
META_WEBHOOK_VERIFY_TOKEN=nexia_webhook_verify
META_WABA_ID=...
META_APP_SECRET=...
NFEIO_API_KEY=...
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM=+55...
TTLOCK_CLIENT_ID=...
TTLOCK_ACCESS_TOKEN=...
NEXIA_APP_URL=https://seu-site.netlify.app
NODE_ENV=production
```

---

*NEXIA OS v12 — HANDOFF v22 — 2026-03-28*
