# NEXIA OS v12 — HANDOFF v21 (CORREÇÕES)
**Data:** 2026-03-28  
**Sessão:** Revisão e correção completa do zip NEXIA_OS_v21_FINAL  
**Executado por:** Claude (Anthropic) via revisão automatizada  

---

## ✅ O QUE FOI CORRIGIDO NESTA SESSÃO

### 🔴 CRÍTICOS (quebravam produção silenciosamente)

#### 1. `netlify.toml` — Catch-all `/*` bloqueando todas as rotas v19/v20
**Problema:** O redirect `/* → /index.html` estava na **linha 121**, antes das rotas adicionadas nas sessões v19 e v20. Isso fazia com que `/api/architect`, `/api/whatsapp`, `/api/nfe`, `/api/dynamic-pricing`, `/api/sentinel`, `/nexia/my-panel`, `/nexia/pabx` retornassem o `index.html` em vez de chamar as funções serverless.  
**Fix:** Catch-all movido para o **final absoluto** do arquivo.

#### 2. `DEPLOY_GUIDE.md` — Chave de API do Groq exposta
**Problema:** `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` estava hardcoded no guia.  
**Fix:** Removida. Substituída por instrução de geração.  
**⚠️ AÇÃO NECESSÁRIA:** Revogar essa chave imediatamente em console.groq.com → API Keys.

#### 3. `netlify/functions/` — 22 funções com SyntaxError no cabeçalho
**Problema:** Todos os arquivos tinham o comentário de bloco iniciando com ` * ╔` sem o `/**` de abertura. Node.js interpretava o `*` como operador de multiplicação → `SyntaxError: Unexpected token '*'` em runtime.  
**Fix:** `/**` adicionado em todos os 22 arquivos afetados.

#### 4. `netlify/functions/cortex-logs.js` — Módulo inteiro duplicado
**Problema:** O arquivo tinha 211 linhas = o módulo repetido duas vezes. `const admin` declarado duas vezes → `SyntaxError: Identifier 'admin' has already been declared`.  
**Fix:** Segunda cópia removida. Arquivo agora com 119 linhas.

#### 5. `netlify/functions/nfe-engine.js` — `await` em função não-async
**Problema:** `.catch(() => ({ raw: await res.text() }))` — `await` dentro de arrow function síncrona → `SyntaxError`.  
**Fix:** Convertido para bloco `try/catch` assíncrono correto.

#### 6. `nexia/tenant-hub.html` — 2 rotas de API inexistentes
**Problema:** Chamava `/api/action` (não existe) e `/api/chat` (não existe). Toda funcionalidade de CRM e chat do tenant estava retornando 404.  
**Fix:** `/api/action` → `/api/actions`, `/api/chat` → `/api/cortex`.

---

### 🟠 IMPORTANTES

#### 7. `core/auth.js` — Redirects com caminhos relativos quebrados
**Problema:** `logout()`, `requireAuth()` e `_autoGuard()` usavam `'../login.html'` — quebra em páginas na raiz ou em subpastas diferentes.  
**Fix:** Todos os redirects convertidos para `/login` (caminho absoluto).

#### 8. `core/governance.js` — Redirect para arquivo inexistente
**Problema:** `validateAccess()` redirecionava para `/nexia/index.html` (arquivo que não existe).  
**Fix:** Corrigido para `/login`.

#### 9. `netlify/functions/multi-model-engine.js` — Crash sem tratamento
**Problema:** Se `modelKey` fosse desconhecido, `const { provider, id } = model` explodia com `TypeError: Cannot destructure undefined`. Se a API key estivesse ausente, fazia fetch com `Bearer undefined`.  
**Fix:** Guards adicionados com mensagens de erro claras.

#### 10. `netlify/functions/whatsapp-business.js` — Webhook sem validação HMAC
**Problema:** Qualquer pessoa podia fazer POST para `/api/whatsapp` fingindo ser a Meta.  
**Fix:** Validação HMAC-SHA256 com `META_APP_SECRET` adicionada.

#### 11. `firestore.rules` — 8 coleções sem regras de segurança
**Problema:** `kill_switch`, `shadow_access`, `audit_log_global`, `empire_metrics`, `nexia_permissions_matrix`, `billing_engine`, `onboarding/architect` não tinham regras → fallback permissivo do Firestore.  
**Fix:** Regras específicas adicionadas para cada coleção.

#### 12. `_redirects` — Catch-all duplicado conflitando com `netlify.toml`
**Problema:** Ambos os arquivos tinham `/* → /index.html`, causando comportamento imprevisível.  
**Fix:** Removido do `_redirects` (gerenciado exclusivamente pelo `netlify.toml`).

---

### 🟡 INCONSISTÊNCIAS

#### 13. Firebase SDK — 4 versões diferentes no projeto
`9.22.0`, `9.23.0`, `10.7.1`, `10.12.0` coexistindo. Todos os arquivos padronizados para `10.7.1`.

#### 14. Versões do projeto inconsistentes
`package.json` dizia `10.1.0`, `name: nexia-os-v10`. DEPLOY_GUIDE dizia v10.1. seed-firebase.js dizia v10.1. Todos atualizados para v12.

#### 15. DEPLOY_GUIDE referenciava Stripe (não usado)
`billing.js` usa Mercado Pago. Referências ao Stripe removidas, variáveis reais (MP, Meta, NFe.io, Twilio, TTLock) adicionadas.

#### 16. `core/config.js` — `allowDebug: true` em produção
Todos os logs internos ficavam visíveis no console. Corrigido para só ativar em `localhost` ou via `localStorage.getItem('nexia_debug')`.

#### 17. `core/governance.js` — CRLF (Windows line endings)
Normalizado para LF.

#### 18. 7 funções serverless com CRLF
`swarm.js`, `action-engine.js`, `agents.js`, `auth.js`, `cortex-agent.js`, `observability.js`, `usage.js`. Todos normalizados.

#### 19. `firebase.json` — Rewrite `**` capturaria chamadas `/api/`
Corrigido para excluir `/api/**` do rewrite de SPA.

#### 20. `META_APP_SECRET` não documentado
Adicionado ao `DEPLOY_GUIDE.md` e ao comentário de env vars no `netlify.toml`.

---

## ✅ VALIDAÇÃO FINAL

```
node --check netlify/functions/*.js  → ✓ TODOS os 29 arquivos: sintaxe válida
node --check core/*.js               → ✓ Todos os 11 arquivos: sintaxe válida
Firebase SDK                         → ✓ 10.7.1 uniforme em todos os HTMLs
Rotas netlify.toml                   → ✓ catch-all no final, todas as rotas mapeadas
```

---

## 🚧 O QUE AINDA FALTA FAZER (PRÓXIMAS SESSÕES)

### PRIORIDADE 1 — Funcional em Produção

#### A. Revisar todos os HTMLs grandes (studio, pabx, nexia-master-admin, flow, cortex-app)
Os arquivos HTML principais **não foram revisados em profundidade**. Há risco de:
- Botões fake (onclick sem lógica real)
- Chamadas a endpoints que não existem
- Estados de loading/erro sem tratamento
- `studio.html` usa Firebase modular (ESM) enquanto `core/config.js` usa compat — pode conflitar

**Arquivos para revisar:**
```
nexia/studio.html          (96KB) — Builder
nexia/nexia-master-admin.html (101KB) — Admin NEXIA
nexia/cortex-app.html      (53KB) — Chat + RAG
nexia/flow.html            (68KB) — Motor de automações
nexia/pabx-softphone.html  (35KB) — Softphone WebRTC
nexia/nexia-pay.html       (34KB) — Pagamentos
splash/splash-admin.html   (121KB) — Admin do Splash
viajante-pro/vp-admin.html (91KB) — Admin VP
```

#### B. `studio.html` — Conflito de SDK Firebase
`studio.html` importa Firebase via **ESM modular** (`import { initializeApp } from 'https://...'`) enquanto o resto do projeto usa **Firebase Compat** (`firebase.initializeApp()`). Isso pode causar instâncias duplicadas do Firebase e erros de autenticação.  
**Fix necessário:** Unificar para Compat OU migrar tudo para Modular.

#### C. Criar `login.html` funcional (ou confirmar que está completo)
`login.html` existe mas não foi revisado em profundidade. Verificar:
- Redirect pós-login correto por role (master → `/nexia/`, tenant → `/nexia/tenant-hub.html`)
- Tratamento de erros (senha errada, email não encontrado)
- Loading state

#### D. Testes E2E
O arquivo `tests/e2e-v20.js` referencia endpoints que estavam quebrados pelo bug do catch-all. Rodar os testes após deploy para confirmar que tudo funciona:
```bash
TEST_URL=https://SEU-SITE.netlify.app node tests/run-tests.js
```

---

### PRIORIDADE 2 — Funcionalidades Prometidas Não Implementadas

#### E. Store → 120 módulos (está em 58/120 — 48%)
HANDOFF v20 promete 120 módulos. Faltam ~62 módulos.  
Verticais sugeridas: saúde, educação, logística, juridico, RH.

#### F. Swarm UI em tempo real
HANDOFF v20 lista como ❌ Falta:
> "Componente React do Swarm em tempo real — websocket para ver agentes executando ao vivo"  
**Implementar:** WebSocket ou SSE conectado ao Firestore `cortex_jobs` para visualização ao vivo.

#### G. App PWA para hóspedes (Viajante Pro / Splash)
HANDOFF v20 lista como ❌ Falta:
> "App mobile PWA completo — recebe senha IoT, mapas, SOS"

#### H. Integração Sentinel IoT ↔ Splash
Reserva confirmada no Splash deve disparar automaticamente a criação de senha na fechadura TTLock.  
Sentinel IoT tem a função `provision_for_booking` — falta o gatilho no Splash.

#### I. Certificação ICP-Brasil (A3)
Validador de certificado digital A3 via webcomponent.

---

### PRIORIDADE 3 — Melhorias Técnicas

#### J. Rate limiting no Mercado Pago webhook
`payment-engine.js` não valida a assinatura do webhook do Mercado Pago. Similar ao que foi feito com o WhatsApp, adicionar validação de `x-signature` com `HMAC-SHA256`.

#### K. `middleware.js` — Rate limit sem TTL automático no Firestore
Os docs de `rate_limits` têm campo `ttl` mas o Firestore não apaga automaticamente. Configurar **TTL policy** no Firestore Console:  
`firestore → rate_limits → TTL field: ttl`

#### L. `nexia-engine.js` — `NexiaTenantEngine` e `NexiaRuntime` não estão documentados como usados
Verificar se `NexiaRuntime.boot()` está sendo chamado nos HTMLs que incluem `nexia-engine.js`.

#### M. Adicionar `.gitignore` ao projeto
Não existe `.gitignore`. Risco de commitar:
- `serviceAccount.json` (credenciais Firebase)
- `.env` 
- `node_modules/`

**Criar `.gitignore`:**
```
serviceAccount.json
.env
.env.local
node_modules/
*.log
```

#### N. `seed-firebase.js` hardcoda `nexia-c8710`
Se o projeto for renomeado/migrado, o seed vai criar dados no projeto errado.

---

## 📋 VARIÁVEIS DE AMBIENTE COMPLETAS (v21)

```bash
# Firebase
FIREBASE_SERVICE_ACCOUNT='{...json completo em uma linha...}'

# AI
ANTHROPIC_API_KEY=sk-ant-...
GROQ_API_KEY=gsk_...          ← REVOGAR A CHAVE ANTIGA! Gerar nova em console.groq.com
OPENAI_API_KEY=sk-...
DEEPSEEK_API_KEY=...

# Pagamentos
MP_ACCESS_TOKEN=APP_USR-...

# WhatsApp / Meta
META_WHATSAPP_TOKEN=EAA...
META_WEBHOOK_VERIFY_TOKEN=nexia_webhook_verify
META_WABA_ID=...
META_APP_SECRET=...            ← NOVO (necessário para segurança do webhook)

# Fiscal
NFEIO_API_KEY=...

# PABX
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM=+55...

# IoT
TTLOCK_CLIENT_ID=...
TTLOCK_ACCESS_TOKEN=...

# App
NEXIA_APP_URL=https://seu-site.netlify.app
NODE_ENV=production
```

---

## 🚀 COMO FAZER DEPLOY AGORA

```bash
# 1. Extrair o ZIP corrigido
unzip NEXIA_OS_v21_CORRIGIDO.zip -d nexia_deploy
cd nexia_deploy

# 2. Revogar chave Groq antiga PRIMEIRO
# → console.groq.com → API Keys → revogar gsk_lpYMwlLqYIRHnAO9dHCCWGdyb3FY...

# 3. Firebase (regras + indexes)
firebase use nexia-c8710
firebase deploy --only firestore:rules,firestore:indexes

# 4. Seed do banco (primeira vez)
cp /caminho/serviceAccount.json ./serviceAccount.json
node seed-firebase.js

# 5. Configurar variáveis no Netlify Dashboard
# → Site → Site configuration → Environment variables
# Adicionar todas as variáveis listadas acima

# 6. Deploy
netlify deploy --prod

# 7. Testar
TEST_URL=https://SEU-SITE.netlify.app node tests/run-tests.js
curl https://SEU-SITE.netlify.app/api/observe
```

---

## 📁 ESTRUTURA DO ZIP CORRIGIDO

```
nexia_fixed/
├── HANDOFF_v21_CORRECOES.md   ← ESTE ARQUIVO
├── DEPLOY_GUIDE.md            ← Atualizado (Stripe removido, vars v12 adicionadas)
├── netlify.toml               ← CORRIGIDO (catch-all no fim)
├── _redirects                 ← CORRIGIDO (catch-all duplicado removido)
├── firebase.json              ← CORRIGIDO (rewrite SPA corrigido)
├── firestore.rules            ← CORRIGIDO (8 coleções faltantes adicionadas)
├── package.json               ← CORRIGIDO (versão 12.0.0)
├── seed-firebase.js           ← CORRIGIDO (versão atualizada)
├── core/
│   ├── config.js              ← CORRIGIDO (allowDebug, nota Firebase config)
│   ├── auth.js                ← CORRIGIDO (redirects absolutos)
│   ├── governance.js          ← CORRIGIDO (CRLF, redirect /login)
│   └── ... (8 outros — OK)
├── nexia/
│   ├── tenant-hub.html        ← CORRIGIDO (/api/action→/api/actions, /api/chat→/api/cortex)
│   └── ... (13 outros — não revisados em profundidade, ver item A)
├── netlify/functions/         ← 29 funções — TODAS com sintaxe válida
│   ├── whatsapp-business.js   ← CORRIGIDO (HMAC webhook)
│   ├── multi-model-engine.js  ← CORRIGIDO (guard modelo inválido + key ausente)
│   ├── nfe-engine.js          ← CORRIGIDO (await em catch)
│   ├── cortex-logs.js         ← CORRIGIDO (duplicata removida)
│   └── ... (22 com /** corrigido, 7 com CRLF corrigido)
└── ...
```

---

*Handoff gerado automaticamente em 2026-03-28 — NEXIA OS v12 Correção Completa*
