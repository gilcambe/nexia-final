# NEXIA OS v12 — HANDOFF_v15.md
**Data:** 27/03/2026 | **Sessão:** 7 | **Status:** Em desenvolvimento ativo

---

## ✅ O QUE FOI FEITO NESTA SESSÃO (Sessão 7)

### ✅ PRIORIDADE 4 — CONCLUÍDA — Bezsan Admin (bezsan/bezsan-admin.html — 902 linhas)
**Refatoração completa** — v9 antigo (523 linhas, só kanban) → v12 Design System
- **Accent color:** `--gold: #DAA520` em toda a interface
- **Sidebar accordion** idêntico ao padrão v12

#### Páginas implementadas:
- [x] **Dashboard** — KPIs (valor em risco, retorno potencial, leilões ativos, arrematados), 2 charts, CORTEX Insights
- [x] **Leilões & Editais** — Tabela completa com busca/filtro por tipo e status, cards com risk meter visual, CRUD com Firebase
- [x] **CORTEX Sniper** — Regras de lance automático, log de execuções, motor de alertas
- [x] **Pipeline CRM** — Kanban drag & drop (Lead → Qualificado → Proposta → Fechado), Firebase real
- [x] **Due Diligence IA** — Upload PDF real, análise com Anthropic API (document block), histórico
- [x] **Contratos PKI** — Tabela de contratos com hash SHA-256 simulado, status ICP-Brasil
- [x] **Financeiro** — KPIs ROI, 2 charts (fluxo caixa + alocação), tabela transações
- [x] **NEXIA Shield** — Audit trail com hash SHA-256, log imutável com Firebase
- [x] **Compliance LGPD** — Checklist de 7 itens com status visual
- [x] **CORTEX Co-Pilot** — Chat IA real com Anthropic API, contexto de leilões, fallback offline
- [x] **Configurações** — API Key Anthropic, Firebase, Mercado Pago, toggles de alertas

---

### ✅ PRIORIDADE 5 — CONCLUÍDA — Viajante Pro Admin (viajante-pro/vp-admin.html — ~870 linhas)
**Refatoração completa** — v9 antigo (514 linhas, só kanban) → v12 Design System
- **Accent color:** `--cyan: #00E5FF` em toda a interface

#### Páginas implementadas:
- [x] **Dashboard** — KPIs (receita mês, PAX, ocupação, roteiros ativos), 2 charts, CORTEX Insights
- [x] **Roteiros & Pacotes** — CRUD completo, filtro status, tabela com ocupação visual
- [x] **Rooming List** — Drag & Drop visual por quartos e hotéis, Firebase, colunas por tipo de quarto
- [x] **Check-in PAX** — Scanner QR simulado + check-in manual, barra de progresso, histórico, export CSV
- [x] **Pipeline CRM** — Kanban 5 stages (Lead → Cotação → Proposta → Pagamento → Emitido), D&D
- [x] **Base de Passageiros** — Tabela completa, busca, status VIP, perfil 360 stub
- [x] **GPS Tempo Real** — Mapa SVG simulado com pins animados, frota list, eventos ao vivo (5s)
- [x] **PABX Cloud** — Softphone funcional (teclado numérico, ligar/encerrar), histórico chamadas, URA builder, toggle online/offline
- [x] **NEXIA Pay Split** — KPIs + chart, motor de split com regras, tabela transações
- [x] **CORTEX Co-Pilot** — Chat IA real com Anthropic API, contexto turismo, fallback
- [x] **Alertas Preditivos** — Cards de alertas críticos/médios (voo, ocupação, comissão)
- [x] **Configurações** — API Key, VoIP provider, Firebase, toggles

---

## 📁 ESTRUTURA ATUAL COMPLETA

```
nexia_output/
├── nexia/
│   ├── nexia-master-admin.html  ✅ v12 (1029 linhas)
│   ├── nexia-store.html         ✅ v12 (736 linhas)
│   ├── tenant-hub.html          ✅ OK
│   ├── cortex-app.html          ✅ OK
│   ├── swarm-control.html       ✅ OK
│   └── pki-scanner.html         ✅ OK
├── ces/
│   ├── ces-admin.html           ✅ v12 (1719 linhas)
│   ├── ces-landing.html         ✅ FIXADO (2484 linhas)
│   ├── ces-app-executivo.html   ✅ OK
│   ├── ces-app.js               ✅ OK
│   └── checkin.html             ✅ OK
├── bezsan/
│   ├── bezsan-admin.html        ✅ REFATORADO v12 (902 linhas) ← NOVO
│   └── bezsan-landing.html      ✅ OK
├── splash/
│   ├── splash-admin.html        ✅ v12 (1923 linhas)
│   └── splash-landing.html      ✅ OK
├── viajante-pro/
│   ├── vp-admin.html            ✅ REFATORADO v12 (~870 linhas) ← NOVO
│   ├── vp-landing.html          ✅ OK
│   ├── vp-guide.html            ✅ OK
│   └── vp-passenger.html        ✅ OK
└── core/                        ✅ OK (não tocar)
```

---

## 🔴 O QUE AINDA FALTA — ANÁLISE TÉCNICA COMPLETA

### 🎨 PRIORIDADE 6 — Site Builder WYSIWYG (NEXIA Studio)
**Arquivo a criar:** `nexia/studio.html`
**Por que é crítico:** Mencionado em TODOS os documentos como produto principal
- [ ] Iframe live preview do site real
- [ ] Painel esquerdo: componentes draggables (Hero, CTA, Cards, Footer)
- [ ] Auto-save a cada 600ms no Firestore (`pages/{tenantId}/{pageId}`)
- [ ] Editor de: cores hex, textos inline, imagens (URL externa), visibilidade de seções
- [ ] Publicação automática → `tenantId.nexia.com.br`
- [ ] Galeria de templates (mínimo 6 layouts pré-definidos)
- [ ] **Backend que FALTA:** `pages/` com `structure_json`, `published`, `version`

### ⚙️ PRIORIDADE 7 — NEXIA Flow (Motor de Automação)
**Arquivo a criar:** `nexia/flow.html`
**Por que é crítico:** Nenhuma versão existe. É só visual.
- [ ] Editor visual de fluxos (nodes + edges, drag & drop)
- [ ] Triggers: "Lead criado", "Pagamento confirmado", "Timer", "Webhook"
- [ ] Actions: "Enviar WhatsApp", "Criar tarefa", "Atualizar stage CRM", "Chamar API"
- [ ] Engine de execução: fila assíncrona via Netlify Functions
- [ ] Logs de execução com status verde/vermelho
- [ ] **Backend que FALTA:** `flows/` (trigger, actions[]), `executions/` (status, logs)

### 🌍 PRIORIDADE 8 — i18n das Landing Pages
- [ ] `splash/splash-landing.html` — PT/EN/ES
- [ ] `bezsan/bezsan-landing.html` — PT/EN/ES
- [ ] `viajante-pro/vp-landing.html` — PT/EN/ES

### 📞 PRIORIDADE 9 — PABX Backend Real
**Arquivos:** `netlify/functions/pabx-handler.js`
**O VP já tem a UI do softphone, mas falta o motor real:**
- [ ] Integração Twilio ou Zenvia (webhook de chamadas)
- [ ] Endpoint `/api/pabx/call` para iniciar chamada programática
- [ ] Storage de gravações → Firebase Storage
- [ ] Transcrição IA: gravar → enviar para Whisper → salvar texto
- [ ] **Backend que FALTA:** `calls/` (tenant_id, from, to, duration, recording_url, transcript)
- [ ] URA: engine de fluxo com estado (aguardando DTMF)

### 🧠 PRIORIDADE 10 — NEXIA Master: OSINT Hub + Takedown
**Arquivo:** `nexia/nexia-master-admin.html` — adicionar seções
- [ ] OSINT Hub: campo CPF/CNPJ → chamar `/.netlify/functions/osint-query`
  - Aggregar Receita Federal (CNPJ.ws API), Jusbrasil scraper, Serasa (API paga)
  - Exibir: sócios, endereço, score, processos
- [ ] Takedown Engine: form URL + marca → gerar dossiê DMCA via Anthropic API
  - Salvar em `takedowns/{id}` com status tracking
- [ ] **Backend que FALTA:** `netlify/functions/osint-query.js`, `netlify/functions/takedown-gen.js`

### 💳 PRIORIDADE 11 — NEXIA Pay Engine Completo
**O que existe:** Tela de financeiro em todos os admins (com dados mockados)
**O que FALTA para ser um motor real:**
- [ ] `ledger/` — cada transação com debit/credit, balanço calculado
- [ ] `balances/{tenantId}` — available, pending (atualizado por evento)
- [ ] Webhook Mercado Pago com idempotência (salvar `mp_payment_id` único)
- [ ] Subscriptions engine: `subscriptions/` com `status`, `next_billing_date`, `retry_count`
- [ ] Split automático: executar no `onPaymentConfirmed` event
- [ ] **Arquivo:** `netlify/functions/payment-engine.js` (já existe `billing.js`, expandir)

### 📊 PRIORIDADE 12 — Metrics Engine (Dashboard Master)
**O que existe:** KPIs hardcoded no master admin
**O que FALTA:**
- [ ] Agregação cross-tenant real: somar MRR de todos os tenants
- [ ] `metricsService` no Firestore: coleção `metrics/{date}` com snapshot diário
- [ ] LTV calculator, churn rate, cohort básico
- [ ] **Arquivo:** `netlify/functions/metrics-aggregator.js`

---

## 🔧 BACKEND QUE FALTA — RESUMO TÉCNICO

| Módulo | Status | Arquivo Faltante |
|--------|--------|-----------------|
| Studio (builder) | ❌ Não existe | `studio.html` + `pages/` collection |
| Flow (automação) | ❌ Não existe | `flow.html` + `flows/` + `executions/` |
| PABX real | ⚠️ UI existe, motor não | `pabx-handler.js` + `calls/` |
| OSINT Hub | ❌ Só conceito | `osint-query.js` |
| Takedown Engine | ❌ Só conceito | `takedown-gen.js` |
| Pay Engine completo | ⚠️ Parcial | `payment-engine.js` + `ledger/` |
| Metrics Aggregator | ⚠️ Parcial | `metrics-aggregator.js` |
| RBAC completo | ⚠️ Parcial | `middleware.js` expandir |
| Subscriptions | ❌ Não existe | `subscriptions/` collection |

---

## 🎨 DESIGN SYSTEM v12 (IMUTÁVEL)

```css
:root {
  --bg:#07090E; --bg2:#0A0D16; --bg3:#0E1220; --bg4:#111827;
  --border:rgba(255,255,255,.06); --border2:rgba(255,255,255,.10);

  /* Accents por tenant */
  --blue:#0057FF;    /* NEXIA OS + CES */
  --green:#00D68F;   /* Splash */
  --gold:#DAA520;    /* Bezsan ← CORRIGIDO (era #C9A84C) */
  --cyan:#00E5FF;    /* Viajante Pro */

  /* Sempre disponíveis */
  --red:#FF3D71; --purple:#9B5CF6; --orange:#F59E0B;
  --text:#E8F0FF; --text2:rgba(232,240,255,.65); --text3:rgba(232,240,255,.35);

  /* Tipografia */
  --ff:'Sora',sans-serif;
  --ffm:'JetBrains Mono',monospace;
}
```

---

## 🔧 CONFIGURAÇÃO (sem alterações)

```
Firebase: nexia-c8710
Namespace: data/{slug}/{collection}
Slugs: ces | bezsan | splash | viajante-pro | nexia
Anthropic: claude-sonnet-4-20250514 (CORTEX Co-Pilot)
Payments: Mercado Pago (PIX + Cartão)
```

---

## 📊 STATUS GERAL

| Arquivo | Status | Linhas | Sessão |
|---------|--------|--------|--------|
| nexia/nexia-master-admin.html | ✅ v12 | 1029 | S4 |
| nexia/nexia-store.html | ✅ v12 | 736 | S5 |
| ces/ces-admin.html | ✅ v12 | 1719 | S3 |
| ces/ces-landing.html | ✅ FIXADO | 2484 | S3 |
| splash/splash-admin.html | ✅ v12 | 1923 | S6 |
| bezsan/bezsan-admin.html | ✅ v12 NOVO | 902 | S7 |
| viajante-pro/vp-admin.html | ✅ v12 NOVO | ~870 | S7 |
| nexia/studio.html | ❌ Não existe | — | — |
| nexia/flow.html | ❌ Não existe | — | — |

**MRR simulado:** R$ 19.290 | **Tenants:** 4 | **Versão:** 12.3

---

## 💡 COMANDO PARA A PRÓXIMA CONTA/SESSÃO

```
Continue o NEXIA OS v12 a partir do HANDOFF_v15.md.

PRIORIDADE ATUAL: PRIORIDADE 6 — criar nexia/studio.html (NEXIA Studio - Builder Visual)

O Studio é o construtor de sites/landings dos clientes.
Requisitos:
- Painel esquerdo: componentes (Hero, CTA, Cards, Depoimentos, Footer) draggables para o canvas
- Canvas central: iframe live preview + edição inline de textos (contenteditable)
- Painel direito: propriedades do componente selecionado (cor, padding, fonte, visibilidade)
- Auto-save 600ms no Firestore: data/{tenant}/pages/{pageId} com structure_json
- Galeria de templates: mínimo 6 layouts para escolher na criação
- Botão "Publicar" que marca published=true e gera subdomínio
- Design System v12 imutável (accent: --blue: #0057FF para NEXIA OS)
- ZERO mocks — auto-save funcional no Firestore
- Arquivo standalone 100% (sem deps externas), funciona em file://
- CORTEX Co-Pilot: sugestão de copy/seções via Anthropic API (claude-sonnet-4-20250514)
```
