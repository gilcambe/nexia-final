# ✦ NEXIA OS v29 — GUIA DE PRODUÇÃO COMPLETO

## 🔑 VARIÁVEIS DE AMBIENTE (Netlify → Site → Environment Variables)

### OBRIGATÓRIAS (sistema não funciona sem estas)
```
FIREBASE_SERVICE_ACCOUNT    = { ...json da service account do Firebase... }
ANTHROPIC_API_KEY           = sk-ant-...         ← Claude Sonnet/Opus
GROQ_API_KEY                = gsk_...            ← Llama 3 (GERE UMA NOVA — a antiga foi exposta)
```

### RECOMENDADAS (ativam funcionalidades extras)
```
OPENAI_API_KEY              = sk-...             ← GPT-4o + DALL-E 3
DEEPSEEK_API_KEY            = sk-...             ← DeepSeek Coder (melhor para código)
GEMINI_API_KEY              = AIza...            ← Gemini 2.0 Flash / 1.5 Pro
XAI_API_KEY                 = xai-...            ← Grok-3
PERPLEXITY_API_KEY          = pplx-...           ← Busca em tempo real
ELEVENLABS_API_KEY          = ...                ← Síntese de voz
MP_ACCESS_TOKEN             = APP_USR-...        ← Mercado Pago (PIX + cartão)
MP_WEBHOOK_SECRET           = ...                ← Segredo webhook Mercado Pago
NEXIA_APP_URL               = https://seu-site.netlify.app
```

### OPCIONAIS
```
WHATSAPP_TOKEN              = ...                ← WhatsApp Business API (Meta WABA)
WHATSAPP_PHONE_ID           = ...                ← ID do número WhatsApp Business
RESEND_API_KEY              = re_...             ← E-mails transacionais (resend.com)
NEXIA_EMAIL_DOMAIN          = nexia.app          ← Domínio de e-mail
NETLIFY_API_TOKEN           = ...                ← Para domínios customizados por tenant
NETLIFY_SITE_ID             = ...                ← ID do site na Netlify
DUNNING_SECRET              = nexia-dunning-XXX  ← Senha para acionar dunning manualmente
TWILIO_ACCOUNT_SID          = ...                ← PABX outbound (opcional)
TWILIO_AUTH_TOKEN           = ...                ← PABX auth (opcional)
TWILIO_FROM                 = +55...             ← Número Twilio (opcional)
```

---

## 🚀 DEPLOY PASSO A PASSO

### 1. Firebase
```bash
npm install -g firebase-tools
firebase login
firebase use --add   # selecione seu projeto
firebase deploy --only firestore:rules,firestore:indexes,storage
```

### 2. Criar usuário master
```bash
node set-master-role.js SEU_EMAIL@gmail.com
```

### 3. Popular dados iniciais
```bash
node seed-firebase.js
```

### 4. Netlify
- Faça push para GitHub
- Conecte o repo na Netlify
- Configure as variáveis de ambiente (lista acima)
- Deploy automático ativado

---

## ✅ O QUE ESTÁ 100% PRONTO PARA PRODUÇÃO

### Backend (Netlify Functions)
- `cortex-chat.js` — Streaming SSE real, 14 IAs, swarm multi-agente, billing por plano
- `autodev-engine.js` — Geração de projetos completos + 8 ações de pipeline de código
- `cortex-memory.js` — Memória por tenant/usuário com sumarização automática
- `cortex-learn.js` — Auto-aprendizado com exemplos avaliados
- `rag-engine.js` — RAG com TF-IDF + chunking (sem vector DB externo)
- `multi-model-engine.js` — 14 modelos de IA integrados
- `billing.js` — Mercado Pago (PIX + cartão + webhook HMAC)
- `payment-engine.js` — Engine de pagamentos
- `auth.js` — Firebase Auth + RBAC multi-tenant
- `architect.js` — Onboarding IA com detecção de setor
- `action-engine.js` — CRM actions (criar cliente, tarefa, reunião, finança)
- `tenant-admin.js` — Gestão de tenants
- `dunning-scheduler.js` — ✅ NOVO: cobrança automática (scheduled, roda 09h BRT)
- `tenant-domain.js` — ✅ NOVO: domínios customizados por tenant via Netlify API
- `swarm.js` — Swarm multi-agente
- `middleware.js` — Rate limit, RBAC, sanitização anti-injection
- `notifications.js`, `observability.js`, `cortex-logs.js`, `usage.js`
- `whatsapp-business.js`, `sentinel-iot.js`, `pabx-handler.js`
- `nfe-engine.js`, `osint-query.js`, `takedown-gen.js`

### Frontend
- `nexia/cortex-app.html` — Chat CORTEX com SSE streaming real + **painel AutoDev completo**
- `nexia/nexia-master-admin.html` — Empire View com métricas reais do Firestore
- `nexia/swarm-control.html` — Swarm conectado ao Firestore
- `nexia/tenant-hub.html`, `nexia/my-panel.html`, `nexia/nexia-store.html`
- `nexia/nexia-pay.html`, `nexia/studio.html`, `nexia/architect.html`
- Verticais: CES, Viajante Pro, Bezsan, Splash (4 verticais completas)

### Infraestrutura
- `firestore.rules` — Isolamento por tenant + regras de segurança completas
- `storage.rules` — ✅ NOVO: regras Firebase Storage por tenant
- `firestore.indexes.json` — 60 índices cobrindo todas as queries
- `netlify.toml` — Rotas + Scheduled Functions (dunning + metrics)
- Service Workers: VP ✅, CES ✅, Splash ✅ (NOVO)

---

## 🔴 FORA DO ESCOPO DESTE DEPLOY (requer ação externa)

| Item | O que precisa |
|------|--------------|
| WhatsApp Business | Aprovação da Meta (WABA) + número verificado |
| NF-e real | Certificado digital A1/A3 + credenciais SEFAZ |
| Split de pagamentos | Aprovação conta MP Marketplace |
| OCR de passaportes | Google Vision API habilitada no projeto |
| CI/CD GitHub Actions | Criar workflow `.github/workflows/deploy.yml` |

---

## 🧠 USAR O CORTEX PARA GERAR PROJETOS

### Via interface (botão `</>` na toolbar do CORTEX):
1. Clique no botão roxo `</>` na toolbar
2. Descreva o projeto em linguagem natural
3. Escolha tipo e stack (ou deixe Auto)
4. Clique "Gerar Projeto Completo"
5. Visualize os arquivos, baixe o .txt ou envie ao chat

### Via API direta:
```bash
curl -X POST https://seu-site.netlify.app/api/autodev \
  -H "Content-Type: application/json" \
  -d '{
    "action": "generate_project",
    "description": "API REST de autenticação com Firebase + JWT",
    "stack": "netlify-functions",
    "userId": "SEU_UID",
    "tenantId": "nexia"
  }'
```

### Pipeline de código (review, fix, refactor, test, security, optimize, docs, explain):
```bash
curl -X POST https://seu-site.netlify.app/api/autodev \
  -H "Content-Type: application/json" \
  -d '{
    "action": "security",
    "code": "function login(user, pass) { ... }",
    "language": "javascript",
    "userId": "SEU_UID",
    "tenantId": "nexia"
  }'
```

---

## 📊 PLANOS E LIMITES

| Plano    | Msgs/dia CORTEX | AutoDev | Preço |
|----------|-----------------|---------|-------|
| master   | ∞ ilimitado     | ✅      | —     |
| enterprise | ∞ ilimitado  | ✅      | —     |
| pro      | 5.000           | ✅      | R$297 |
| starter  | 500             | ✅      | R$97  |
| free     | 50              | ✅      | R$0   |

---
*NEXIA OS v29 — Geração: ${new Date().toLocaleDateString('pt-BR')} — Proprietário: Gildivan © 2027*
