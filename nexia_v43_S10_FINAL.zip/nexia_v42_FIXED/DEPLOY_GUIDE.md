# NEXIA OS v12 — GUIA DE DEPLOY COMPLETO
## Do zero ao ar em produção

---

## PRÉ-REQUISITOS

```bash
npm install -g firebase-tools netlify-cli
firebase login
netlify login
```

---

## PASSO 1 — Firebase: Regras e Indexes

```bash
# Na raiz do projeto (onde está firebase.json):
firebase use nexia-c8710

# Publica regras de segurança (firestore.rules)
firebase deploy --only firestore:rules

# Publica indexes (firestore.indexes.json)
# ⚠️ Indexes podem levar 5-10 minutos para build no Firebase
firebase deploy --only firestore:indexes
```

---

## PASSO 2 — Seed do banco de dados

```bash
# Coloque o arquivo da service account na pasta:
# nexia-c8710-firebase-adminsdk-fbsvc-fbdb48cb78.json → renomeie para serviceAccount.json

cp nexia-c8710-firebase-adminsdk-fbsvc-fbdb48cb78.json serviceAccount.json

# Instala dependência do script
npm install firebase-admin

# Roda o seed (cria tenants, agentes, store catalog, health check)
node seed-firebase.js
```

---

## PASSO 3 — Criar usuário Master no Firebase Auth

1. Acesse: https://console.firebase.google.com/project/nexia-c8710/authentication/users
2. Clique em **"Adicionar usuário"**
3. Email: `admin@nexia.app` (ou o email que preferir)
4. Defina uma senha forte
5. Copie o **UID** gerado (ex: `abc123xyz456`)
6. Rode:

```bash
node set-master-role.js <UID_COPIADO>
```

---

## PASSO 4 — Variáveis de Ambiente no Netlify

Acesse: **Netlify → Seu site → Site configuration → Environment variables**

Adicione uma por uma:

| Variável | Valor |
|---|---|
| `FIREBASE_SERVICE_ACCOUNT` | Cole o JSON inteiro da service account em UMA linha |
| `GROQ_API_KEY` | Gerar em: console.groq.com → API Keys |
| `DEEPSEEK_API_KEY` | Gerar em: platform.deepseek.com → API Keys |
| `OPENAI_API_KEY` | Gerar em: platform.openai.com → API Keys |
| `MP_ACCESS_TOKEN` | Token Mercado Pago: painel.mercadopago.com → Credenciais → Access Token |
| `META_WHATSAPP_TOKEN` | Token Meta Business API (WhatsApp Business) |
| `META_WEBHOOK_VERIFY_TOKEN` | `nexia_webhook_verify` (ou string aleatória sua) |
| `META_WABA_ID` | ID da conta WhatsApp Business (Meta Business Suite) |
| `META_APP_SECRET` | App Secret (Meta for Developers → App → Settings → Basic) — necessário para validar webhooks |
| `NFEIO_API_KEY` | Chave NFe.io (plano empresa) |
| `TWILIO_ACCOUNT_SID` | (PABX) painel.twilio.com → Account SID |
| `TWILIO_AUTH_TOKEN` | (PABX) painel.twilio.com → Auth Token |
| `TWILIO_FROM` | (PABX) Número Twilio no formato +5511... |
| `TTLOCK_CLIENT_ID` | (IoT) TTLock developer portal |
| `TTLOCK_ACCESS_TOKEN` | (IoT) TTLock developer portal |
| `NEXIA_APP_URL` | `https://SEU-SITE.netlify.app` |
| `NODE_ENV` | `production` |

### Como formatar o FIREBASE_SERVICE_ACCOUNT:
```bash
# No terminal, converte o JSON para uma linha só:
cat serviceAccount.json | python3 -c "import json,sys; print(json.dumps(json.load(sys.stdin)))"
# Cole o output completo como valor da variável
```

---

## PASSO 5 — Deploy no Netlify

```bash
# Instala dependências
npm install

# Deploy de produção
netlify deploy --prod

# OU via GitHub (recomendado):
# 1. Push para o branch main
# 2. Netlify faz deploy automático
```

---

## PASSO 6 — Verificação pós-deploy

```bash
# Testa todas as functions:
TEST_URL=https://SEU-SITE.netlify.app node tests/run-tests.js

# Verifica o health check:
curl https://SEU-SITE.netlify.app/api/observe
```

---

## ARQUITETURA — O que está rodando

```
┌─────────────────────────────────────────────────────────┐
│                    NEXIA OS v12                        │
│                                                          │
│  FRONTEND (Netlify CDN)                                  │
│  ├── index.html          → Landing / Router              │
│  ├── login.html          → Auth (Firebase)               │
│  ├── nexia/cortex-app.html → Chat + RAG + Dashboard     │
│  ├── nexia/tenant-hub.html → CRM + Kanban + Finance     │
│  ├── nexia/pipeline.html → Pipeline de vendas            │
│  └── nexia/swarm-control.html → Gestão de agentes       │
│                                                          │
│  BACKEND (Netlify Functions = Serverless)                │
│  ├── /api/cortex      → cortex-chat.js (BRAIN)          │
│  ├── /api/memory      → cortex-memory.js                 │
│  ├── /api/rag         → rag-engine.js                    │
│  ├── /api/autodev     → autodev-engine.js                │
│  ├── /api/swarm       → swarm.js                         │
│  ├── /api/models      → multi-model-engine.js            │
│  ├── /api/agents      → agents.js                        │
│  ├── /api/actions     → action-engine.js (CRUD)          │
│  ├── /api/billing     → billing.js (Stripe)              │
│  ├── /api/usage       → usage.js (Analytics)             │
│  ├── /api/tenant      → tenant-admin.js                  │
│  ├── /api/logs        → cortex-logs.js                   │
│  ├── /api/events      → event-processor.js               │
│  ├── /api/notifications → notifications.js               │
│  ├── /api/auth        → auth.js                          │
│  └── /api/observe     → observability.js                 │
│                                                          │
│  DATABASE (Firebase / Firestore)                         │
│  ├── users/           → Perfis de usuários               │
│  ├── tenants/         → Configuração dos tenants         │
│  │   ├── /clients     → CRM                              │
│  │   ├── /tasks       → Tarefas                          │
│  │   ├── /meetings    → Reuniões                         │
│  │   ├── /finance     → Financeiro                       │
│  │   ├── /pipeline    → Funil de vendas                  │
│  │   ├── /cortex_memory → Memória do Cortex             │
│  │   ├── /rag_index   → Documentos indexados             │
│  │   ├── /usage       → Analytics de uso                 │
│  │   └── /cortex_logs → Logs de execução                 │
│  ├── agents/          → Agentes globais                  │
│  ├── store_catalog/   → NEXIA STORE                      │
│  ├── event_queue/     → Fila de eventos                  │
│  └── cortex_good_responses/ → Auto-aprendizado           │
└─────────────────────────────────────────────────────────┘
```

---

## SOBRE OS 15.000 AGENTES

O seed cria os **agentes base** (11 globais + verticais por tenant).
Para escalar para 15.000 agentes especializados:

```javascript
// Exemplo de batch import de agentes
const agentes = require('./agents-catalog.json'); // seu JSON com 15k agentes
const batch = db.batch();
for (const agente of agentes) {
  const ref = db.collection('agents').doc(agente.id);
  batch.set(ref, { ...agente, createdAt: now }, { merge: true });
  // Firestore batch suporta 500 ops — dividir em chunks de 499
}
await batch.commit();
```

O Cortex já carrega agentes dinamicamente via `loadDynamicAgents(tenantId)` — 
qualquer agente no Firestore com `active: true` é automaticamente disponibilizado 
para o swarm sem nenhuma alteração de código.

---

## MÓDULOS FUTUROS (NEXIA STORE — Em desenvolvimento)

| Módulo | Status | Previsão |
|---|---|---|
| NEXIA Voice (ElevenLabs) | 🟡 Em desenvolvimento | Q3 2025 |
| ARC Architect AI | 🟡 Em desenvolvimento | Q3 2025 |
| AUCTION Intelligence | 🟡 Em desenvolvimento | Q4 2025 |
| NEXIA Identity (biometria) | 🔴 Planejado | Q1 2026 |
| Legal Scraper (Diários Oficiais) | 🔴 Planejado | Q1 2026 |
| Predictive Budgeter | 🔴 Planejado | Q2 2026 |
