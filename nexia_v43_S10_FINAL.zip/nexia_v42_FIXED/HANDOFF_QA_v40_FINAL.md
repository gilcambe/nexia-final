# 🛡️ HANDOFF QA FINAL — NEXIA OS v40
**Engenheiro:** Claude QA Sénior  
**Data:** 2026-04-01  
**Status:** ✅ ANÁLISE COMPLETA — 9 vulnerabilidades corrigidas + 3 bónus  
**Próxima sessão:** Testes de validação pós-fix + itens pendentes

---

## ✅ FIXES APLICADOS NESTA SESSÃO (12 correções em 11 ficheiros)

| ID | Sev | Ficheiro | Problema | Fix |
|----|-----|----------|----------|-----|
| VULN-01 | 🔴 CRÍTICO | `churn-predictor.js` + `kpi-engine.js` | `guard()` sem `await` — APIs abertas sem auth | Adicionado `await` |
| VULN-02 | 🔴 CRÍTICO | `core/auth.js:24` | Novo user sem doc → `tenantSlug:'nexia'` = acesso master | Alterado para `'guest'` |
| VULN-03 | 🔴 CRÍTICO | `middleware.js:143` | fail-open quando Firebase indisponível | Alterado para fail-closed (403) |
| VULN-04 | 🟠 ALTO | `dunning-scheduler.js` | Sem idempotência → alertas/suspensões duplicadas em retry | Adicionada `alreadyActedToday()` |
| VULN-05 | 🟠 ALTO | `dunning-scheduler.js:116` | `DUNNING_SECRET` com fallback hardcoded | Removido fallback; retorna 503 se não configurado |
| VULN-06 | 🟠 ALTO | `whatsapp-business.js:73` | HMAC WhatsApp opcional | Obrigatório; retorna 503 se `META_APP_SECRET` ausente |
| VULN-07 | 🟡 MÉDIO | `firestore.rules:299` | `pages.create` sem verificação de `tenantId` | Adicionado `request.resource.data.tenantId == userTenant()` |
| VULN-08 | 🟡 MÉDIO | `nexia-master-admin.html:1178` | String corrompida em `EXTERNAL_PAGES.scanner` | Corrigida para `'pki-scanner.html'` |
| VULN-09 | 🟡 MÉDIO | `nexia-master-admin.html` + **[NOVO]** `audit-log.js` | Frontend escrevia em `audit_log_global` (create:false nas Rules) — logs perdidos silenciosamente | Criado endpoint `/api/audit` com Admin SDK; frontend redirecionado |
| BÓNUS-01 | 🟡 MÉDIO | `firestore.rules` | `kill_switch read:true` — qualquer anónimo via quem está suspenso | Alterado para `isAuth() && isMember()` |
| BÓNUS-02 | 🟡 MÉDIO | `payment-engine.js` | CORS `*` como fallback | Alterado para URL real do projeto |
| BÓNUS-03 | 🟡 MÉDIO | `firestore.rules` | `event_queue`, `cortex_jobs`, `store_orders` create sem isolamento | Adicionadas verificações de `tenantId`/`userId` |

---

## 📋 PENDENTES — Para Próxima Sessão

### 🟡 P1 — Adicionar `FIREBASE_SERVICE_ACCOUNT_BASE64` ao `.env.example`
**Porquê:** O código suporta as duas variáveis mas não há template documentado. Devs novos podem errar.  
**Ficheiro:** Criar `/home/claude/nexia_v40_FIXED/.env.example` com todas as 35+ vars mapeadas.

### 🟡 P2 — `netlify.toml` CSP: `unsafe-eval` presente
**Ficheiro:** `netlify.toml` linha CSP  
**Problema:** `script-src 'unsafe-eval'` — permite eval() no browser. Necessário verificar se alguma lib (Firebase SDK compat, etc.) ainda precisa ou se pode ser removido.  
**Acção:** Testar remoção em staging. Se não quebrar, remover.

### 🟡 P3 — `login.html` — verificar se tem protecção anti-brute-force
**Acção:** Confirmar se o rate limiting do `middleware.js` cobre o endpoint `/api/auth` para tentativas de login.

### 🟡 P4 — `vp-passenger.html` e `vp-guide.html` — validar role-based access
**Problema:** `_autoGuard()` verifica autenticação mas não verifica se o role do utilizador é `passenger` ou `guide`.  
**Acção:** Adicionar verificação de role dentro das páginas (além da verificação de auth).

### 🟡 P5 — `QA Test Center` — adicionar `/api/audit` aos testes de endpoint
**Ficheiro:** `nexia/qa-test-center.html` — array `APIS`  
**Acção:** Adicionar `{ path:'/api/audit', method:'POST', name:'Audit Log', auth:true, ... }` à lista de testes.

### 🟡 P6 — `nexia-master-admin.html` — `salvarAgente()` e `publicarModulo()` usam IDs inexistentes
**Problema:** `document.getElementById('ag-nome')`, `getElementById('ag-tipo')`, `getElementById('mod-nome')` — os modais usam `placeholder` mas não têm `id` nos inputs. Vai retornar `null` e falhar silenciosamente.  
**Acção:** Adicionar `id="ag-nome"`, `id="ag-tipo"`, `id="ag-prompt"`, `id="mod-nome"`, `id="mod-preco"`, `id="mod-desc"` aos inputs dos modais.

### 🟢 P7 — Smoke test pós-deploy (manual)
1. Login com conta não-master → confirmar redirect para `/nexia/tenant-hub.html`
2. Aceder `/api/churn` sem token → deve retornar **401** (era 200 antes do fix VULN-01)
3. Aceder `/api/kpi` sem token → deve retornar **401**
4. Criar conta nova via Firebase → `tenantSlug` deve ser `'guest'`, não `'nexia'`
5. Disparar dunning 2x no mesmo dia → deve processar apenas uma vez

---

## 🗂️ FICHEIROS ENTREGUES NO ZIP

```
nexia_v40_FIXED/
├── core/
│   └── auth.js                          ← VULN-02 fix
├── firestore.rules                       ← VULN-07 + BÓNUS-01/03 fix
├── netlify.toml                          ← /api/audit redirect adicionado
└── netlify/functions/
    ├── audit-log.js                      ← NOVO — endpoint seguro para audit
    ├── churn-predictor.js               ← VULN-01 fix (await)
    ├── dunning-scheduler.js             ← VULN-04/05 fix (idempotência + secret)
    ├── kpi-engine.js                    ← VULN-01 fix (await)
    ├── middleware.js                    ← VULN-03 fix (fail-closed)
    ├── payment-engine.js               ← BÓNUS-02 fix (CORS)
    └── whatsapp-business.js            ← VULN-06 fix (HMAC obrigatório)
nexia/
    └── nexia-master-admin.html          ← VULN-08/09 fix + NEXIA_UID fix
```

---

## 🔑 VARIÁVEIS DE AMBIENTE OBRIGATÓRIAS (mapeamento completo)

```bash
# Firebase (OBRIGATÓRIO)
FIREBASE_SERVICE_ACCOUNT='{...json...}'   # ou usar BASE64:
FIREBASE_SERVICE_ACCOUNT_BASE64='...'

# IA Models
GROQ_API_KEY=gsk_...
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=...
DEEPSEEK_API_KEY=...

# Pagamentos
MP_ACCESS_TOKEN=APP_USR-...          # Mercado Pago
MP_WEBHOOK_SECRET=...
STRIPE_SECRET_KEY=sk_live_...        # (opcional — Stripe)

# WhatsApp Business (OBRIGATÓRIO para webhook seguro)
META_APP_SECRET=...                  # HMAC validation — obrigatório após VULN-06 fix
META_WHATSAPP_TOKEN=...
META_WEBHOOK_VERIFY_TOKEN=...
META_WABA_ID=...
WHATSAPP_TOKEN=...                   # fallback legacy
WHATSAPP_PHONE_ID=...

# Dunning (OBRIGATÓRIO após VULN-05 fix)
DUNNING_SECRET=...                   # gerar com: openssl rand -hex 32

# App
NEXIA_APP_URL=https://yourdomain.netlify.app
NEXIA_EMAIL_DOMAIN=yourdomain.com
RESEND_API_KEY=re_...                # emails dunning

# Opcionais
METRICS_SECRET=...
NFEIO_API_KEY=...
TTLOCK_ACCESS_TOKEN=...
TTLOCK_CLIENT_ID=...
```

