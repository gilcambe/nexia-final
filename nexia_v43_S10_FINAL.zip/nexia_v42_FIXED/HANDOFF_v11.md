# NEXIA OS v11 — HANDOFF COMPLETO (Sessão 2)
**Data:** 27/03/2026 | **Status:** Em desenvolvimento ativo

---

## ✅ O QUE FOI FEITO NESTA SESSÃO

### 🔥 NEXIA MASTER ADMIN — Rebuild Total (1.029 linhas)
**Arquivo:** `nexia/nexia-master-admin.html`

Sidebar com ACCORDION (blocos que se abrem/fecham) — não poluída:
- **Bloco IMPÉRIO:** Empire View, MRR Global, Tenant Control, Billing
- **Bloco CORTEX IA:** CORTEX Master (chat), Fábrica de Agentes, Swarm, NEXIA Flow
- **Bloco LOJA & PRODUTOS:** NEXIA Store (30 módulos), Aprovações, Broadcast
- **Bloco SEGURANÇA:** Audit Log, OSINT Hub, PKI Scanner, Kill Switch
- **Bloco CONFIGURAÇÃO:** Inscrições Globais, Site Builder, White Label

**Funcionalidades completas:**
| Página | Funcionalidade |
|--------|---------------|
| Empire View | KPIs tempo real, tenant cards, CORTEX alerts preditivos |
| MRR Global | Gráfico 6 meses, tabela por tenant, ARR projetado |
| Tenant Control | Tabela + busca, Shadow Login, Kill Switch individual, export CSV |
| Billing | Aprovação manual Pix, histórico de transações |
| CORTEX Master | Chat Groq, config sistema, terminal debug |
| Fábrica Agentes | 15.284 agentes categorizados, criar com System Prompt |
| Swarm | Orquestração multi-agente com terminal ao vivo |
| NEXIA Flow | 5 automações pré-configuradas com toggles |
| NEXIA Store | 8 módulos exibidos, filtros, adicionar novo módulo |
| Aprovações | 3 módulos aguardando aprovação manual |
| Broadcast | Canais Push/Email/WhatsApp, histórico |
| Audit Log | Logs em tempo real, auto-inserção 10s |
| OSINT Hub | Consulta CPF/CNPJ + Takedown Engine |
| PKI Scanner | Varredura domínio com terminal simulado |
| Kill Switch | Global (senha: NEXIA-GOD-MODE) + por tenant |
| Inscrições Globais | KPIs + tabela completa |
| Site Builder | Seletor dos 4 tenants com link direto |
| White Label | Config visual + preview |

---

## 🔴 O QUE AINDA FALTA (Próxima Sessão)

### PRIORIDADE 1 — CES Admin (refatoração)
**Arquivo:** `ces/ces-admin.html` (1585 linhas existentes)
- [ ] Upload Firebase Storage para fotos de palestrantes
- [ ] Palestrantes CRUD completo com foto e bio
- [ ] Campanhas (WhatsApp/Email/SMS) com broadcast
- [ ] Gráficos de leads (Chart.js)
- [ ] Exportar CSV/PDF de inscrições
- [ ] Integração catraca facial (QR Code check-in)
- [ ] Formulário de check-in salvando no Firestore em tempo real
- [ ] CORTEX integrado como aba (chat dentro do admin)
- [ ] Login guard (verificar se é admin do tenant ces)
- [ ] Refatorar visual para usar o novo design system do NEXIA v11

### PRIORIDADE 2 — NEXIA STORE standalone
**Arquivo:** `nexia/nexia-store.html` (não existe)
- [ ] Criar página standalone com catálogo de 30 módulos
- [ ] Filtros por categoria, busca
- [ ] Carrinho funcional
- [ ] Checkout via Mercado Pago (Pix + Cartão)
- [ ] Ativação 1-clique no Firestore após pagamento

### PRIORIDADE 3 — CORTEX integrado nos Tenant Admins
- [ ] `ces/ces-admin.html` — Aba CORTEX (chat contextualizado para CES)
- [ ] `splash/splash-admin.html` — Aba CORTEX (SDR, precificação dinâmica)
- [ ] `bezsan/bezsan-admin.html` — Aba CORTEX (Due Diligence, Sniper)
- [ ] `viajante-pro/vp-admin.html` — Aba CORTEX (Predictive, GPS)

### PRIORIDADE 4 — Splash Admin (refatoração)
**Arquivo:** `splash/splash-admin.html` (1397 linhas existentes)
- [ ] Calendário anti-overbooking com bloqueio instantâneo
- [ ] Precificação dinâmica (baixa/alta demanda)
- [ ] NEXIA SENTINEL IoT — gerenciamento de fechaduras
- [ ] Mini-site automático por evento (15anosdamaria.splash.com.br)
- [ ] CORTEX SDR — recuperação de carrinho abandonado
- [ ] Catraca digital / QR Code entrada

### PRIORIDADE 5 — Bezsan Admin (refatoração)
**Arquivo:** `bezsan/bezsan-admin.html` (523 linhas existentes)
- [ ] Scraping de leilões judiciais (integração API)
- [ ] Sniper de lances com configuração de teto
- [ ] CORTEX Due Diligence — análise de editais
- [ ] Contratos PDF com Hash SHA256
- [ ] NEXIA Shield — dashboard de segurança

### PRIORIDADE 6 — Viajante Pro Admin (refatoração)
**Arquivo:** `viajante-pro/vp-admin.html` (514 linhas existentes)
- [ ] Rooming list visual drag & drop
- [ ] App do Guia com GPS em tempo real
- [ ] PABX Cloud — softphone WebRTC
- [ ] CORTEX Predictive — alertas de voos
- [ ] NEXIA Pay Split — divisão automática de comissões

### PRIORIDADE 7 — Site Builder WYSIWYG
- [ ] Iframe do site real + edição ao vivo
- [ ] Auto-save a cada 600ms
- [ ] Editor de: cores, textos, imagens, seções
- [ ] Exportar HTML limpo

### PRIORIDADE 8 — i18n PT/EN/ES
- [ ] Todas as landing pages com seletor de idioma
- [ ] Tradução completa dos textos
- [ ] Persistência via localStorage

---

## 📁 ESTRUTURA DE ARQUIVOS ATUAL

```
nexia-merged/
├── nexia/
│   ├── nexia-master-admin.html  ✅ REBUILT (v11, 1029 linhas)
│   ├── nexia-store.html         ❌ NÃO EXISTE (criar)
│   ├── tenant-hub.html          ✅ OK
│   ├── cortex-app.html          ✅ OK
│   ├── swarm-control.html       ✅ OK
│   └── pki-scanner.html         ✅ OK
├── ces/
│   ├── ces-admin.html           ⚠️ REFATORAR (1585 linhas)
│   ├── ces-landing.html         ✅ OK
│   ├── ces-app-executivo.html   ✅ OK
│   └── checkin.html             ✅ OK
├── bezsan/
│   ├── bezsan-admin.html        ⚠️ REFATORAR (523 linhas)
│   └── bezsan-landing.html      ✅ OK
├── splash/
│   ├── splash-admin.html        ⚠️ REFATORAR (1397 linhas)
│   └── splash-landing.html      ✅ OK
├── viajante-pro/
│   ├── vp-admin.html            ⚠️ REFATORAR (514 linhas)
│   ├── vp-landing.html          ✅ OK
│   ├── vp-guide.html            ✅ OK
│   └── vp-passenger.html        ✅ OK
├── core/
│   ├── config.js                ✅ OK (Firebase config)
│   ├── auth.js                  ✅ OK
│   ├── nexia-engine.js          ✅ OK
│   ├── nexia-splash.js          ✅ OK (splash screen 1.2s)
│   └── admin.css                ✅ OK (design tokens)
├── netlify/functions/           ✅ 18 functions OK
├── firestore.rules              ✅ OK
├── firestore.indexes.json       ✅ OK
└── login.html                   ✅ OK
```

---

## 🎨 DESIGN SYSTEM v11

```css
/* Cores principais */
--bg:       #07090E  /* Fundo profundo */
--bg2:      #0A0D16  /* Sidebar, cards */
--bg3:      #0E1220  /* Inputs, sub-cards */
--gold:     #DAA520  /* Acento principal NEXIA */
--cyan:     #00E5FF  /* Ações, links */
--green:    #00D68F  /* Sucesso, online */
--red:      #FF3D71  /* Kill Switch, erro */
--purple:   #9B5CF6  /* Impersonate, premium */
--orange:   #F59E0B  /* Alertas, avisos */

/* Fonts */
--ff:  'Sora', sans-serif       /* UI principal */
--ffm: 'JetBrains Mono', mono  /* Código, KPIs, timestamps */

/* Classes reutilizáveis */
.btn.bg  → Botão gold
.btn.br  → Botão red (Kill)
.btn.bc  → Botão cyan
.ab.c/.g/.r/.p/.gn → Action buttons pequenos
.pill.on/.off/.trial → Status pills
.nbadge.live/.hot/.gold/.new → Badge sidebar
```

---

## 🔧 CONFIGURAÇÃO FIREBASE

```javascript
// Projeto: nexia-c8710
const NEXIA_FIREBASE_CONFIG = {
  apiKey: "AIzaSyC9L592zKSUjx-YglmbGpxjv2hsXm_gbBM",
  authDomain: "nexia-c8710.firebaseapp.com",
  projectId: "nexia-c8710",
  // ... em core/config.js
};
// Namespace: data/{tenantSlug}/{collection}
// Tenants: ces, bezsan, splash, viajante-pro, nexia
```

---

## 💡 INSTRUÇÕES PARA A PRÓXIMA CONTA

### Como continuar:
1. **Baixar** o zip `NEXIA_OS_v11_COMPLETE.zip` do output
2. **Ler** este HANDOFF_v11.md primeiro
3. **Ler** o arquivo `O_QUE_É_A_NEXIA.txt` para entender o contexto
4. **Começar** por PRIORIDADE 1 (CES Admin refatoração)

### Padrão de desenvolvimento:
- Todo admin usa o design system v11 (ver tokens acima)
- Sidebar SEMPRE com accordion (blocos que se abrem)
- CORTEX integrado como aba dentro do admin, não página separada
- Login guard em TODOS os admins
- Firestore: sempre usar namespace `data/{slug}/{collection}`
- Splash screen 1.2s com logo ✦ NEXIA OS em todas as páginas

### Comando para a próxima IA:
```
"Continue o NEXIA OS v11 a partir do HANDOFF_v11.md. 
Comece pela PRIORIDADE 1: refatorar ces/ces-admin.html 
com o novo design system, CORTEX integrado como aba, 
upload de fotos Firebase Storage, e campanhas de marketing."
```

---

**MRR atual:** R$ 19.290 | **Tenants:** 4 | **Agentes:** 15.284 | **Versão:** 11.0
