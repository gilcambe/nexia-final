# ✦ NEXIA OS — CORTEX v14 — GUIA DE PRODUÇÃO

## O QUE O CORTEX v14 FAZ

O CORTEX é o **orquestrador universal de IAs** do NEXIA OS.
Ele analisa cada mensagem e automaticamente usa a melhor IA para a tarefa:

| Tarefa | IA Usada |
|--------|----------|
| Escrita, jurídico, estratégia | Claude Sonnet 4.5 |
| Análise, visão, multimodalidade | GPT-4o |
| Velocidade extrema | Groq Llama 3 70B |
| Código pesado | DeepSeek Coder |
| Documentos gigantes (2M tokens) | Gemini 1.5 Pro |
| Tempo real / tendências | Grok-3 |
| Busca web em tempo real | Perplexity |
| Imagens | DALL-E 3 |
| Voz | ElevenLabs |
| Multi-perspectiva | Swarm (Dev+Security+Business) |

## LIMITES POR PLANO

| Plano | Msgs/dia | Tokens por resposta |
|-------|----------|---------------------|
| **Master (Gildivan)** | **ILIMITADO** | **32.000** |
| **Enterprise** | **ILIMITADO** | **32.000** |
| Pro | 5.000 | 8.192 |
| Starter | 500 | 8.192 |
| Free | 50 | 8.192 |

## VARIÁVEIS DE AMBIENTE NO NETLIFY

Vá em: **Netlify Dashboard → Site → Site configuration → Environment variables**

### OBRIGATÓRIAS (sistema não funciona sem estas)
```
FIREBASE_SERVICE_ACCOUNT = { ...json completo em UMA linha... }
ANTHROPIC_API_KEY        = sk-ant-...   ← Claude Sonnet 4.5
GROQ_API_KEY             = gsk_...      ← Gerar NOVA chave (antiga foi exposta)
```

### RECOMENDADAS (habilitam mais IAs)
```
OPENAI_API_KEY           = sk-...       ← GPT-4o + DALL-E 3 (imagens)
DEEPSEEK_API_KEY         = ...          ← DeepSeek Coder
GEMINI_API_KEY           = ...          ← Gemini 1.5 Pro
XAI_API_KEY              = ...          ← Grok-3
PERPLEXITY_API_KEY       = pplx-...     ← Busca web tempo real
```

### CAPACIDADES EXTRAS
```
ELEVENLABS_API_KEY       = ...          ← Síntese de voz
META_WHATSAPP_TOKEN      = EAA...       ← WhatsApp Business
META_WEBHOOK_VERIFY_TOKEN= nexia_webhook_verify
NFEIO_API_KEY            = ...          ← Emissão de NF-e
MP_ACCESS_TOKEN          = APP_USR-...  ← Mercado Pago
MP_WEBHOOK_SECRET        = ...          ← Webhook MP
NEXIA_APP_URL            = https://seusite.netlify.app
NODE_ENV                 = production
```

## COMO GARANTIR QUE VOCÊ É MASTER (SEM LIMITE)

No Firebase, seu usuário deve ter `plan: "master"` no documento `tenants/nexia`
OU o campo `tenantSlug: "nexia"` no documento `users/{seu_uid}`.

Para setar via script:
```bash
node set-master-role.js
```

## TESTE RÁPIDO PÓS-DEPLOY

1. Acesse `/login.html` e entre com conta master
2. Vá para `/nexia/cortex-app.html`
3. Veja `∞ ILIMITADO` no canto superior direito
4. Envie: `"Crie um componente React de login com Firebase"`
5. A resposta deve streamar em tempo real com DeepSeek Coder

## STREAMING SSE

O CORTEX usa streaming real token-a-token via SSE para:
- Anthropic Claude → `streamAnthropic()` — streaming nativo
- OpenAI GPT-4o → `streamOpenAI()` — streaming nativo
- Groq → `streamGroq()` — streaming nativo (mais rápido)
- Perplexity → `streamPerplexity()` — streaming nativo
- DeepSeek / Gemini / Grok → resposta completa emitida de uma vez (SSE simulado)

## ARQUIVOS DO CORTEX

```
netlify/functions/
├── cortex-chat.js      ← ORQUESTRADOR PRINCIPAL (v14)
├── multi-model-engine.js ← Router de modelos (inclui Anthropic)
├── middleware.js        ← Auth + rate limits aumentados
├── cortex-memory.js     ← Memória de conversas
├── cortex-learn.js      ← Aprendizado contínuo
├── rag-engine.js        ← Documentos como contexto
├── cortex-agent.js      ← Agente com tool-use
└── swarm.js             ← Multi-agente paralelo

nexia/
└── cortex-app.html      ← FRONTEND v14 (streaming + todos os modelos)
```
