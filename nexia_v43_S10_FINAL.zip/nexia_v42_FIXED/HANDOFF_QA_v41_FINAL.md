# 🛡️ HANDOFF QA FINAL — NEXIA OS v41
**Engenheiro:** Claude QA Sénior  
**Data:** 2026-04-01  
**Status:** ✅ COMPLETO — 18 vulnerabilidades/issues corrigidos em 3 sessões  
**Próxima sessão:** Smoke tests pós-deploy (manual) — ver checklist abaixo

---

## ✅ SESSÃO 1 — VULN Críticas + Altas + Médias (12 fixes)

| ID | Sev | Ficheiro | Problema | Fix |
|----|-----|----------|----------|-----|
| VULN-01 | 🔴 CRÍTICO | `churn-predictor.js` + `kpi-engine.js` | `guard()` sem `await` — APIs abertas sem auth | Adicionado `await` |
| VULN-02 | 🔴 CRÍTICO | `core/auth.js` | Novo user sem doc → `tenantSlug:'nexia'` = acesso master | Alterado para `'guest'` |
| VULN-03 | 🔴 CRÍTICO | `middleware.js` | fail-open quando Firebase indisponível | Alterado para fail-closed (403) |
| VULN-04 | 🟠 ALTO | `dunning-scheduler.js` | Sem idempotência → alertas/suspensões duplicadas em retry | Adicionada `alreadyActedToday()` |
| VULN-05 | 🟠 ALTO | `dunning-scheduler.js` | `DUNNING_SECRET` com fallback hardcoded | Removido fallback; retorna 503 se ausente |
| VULN-06 | 🟠 ALTO | `whatsapp-business.js` | HMAC WhatsApp opcional | Obrigatório; retorna 503 se `META_APP_SECRET` ausente |
| VULN-07 | 🟡 MÉDIO | `firestore.rules` | `pages.create` sem verificação de `tenantId` | Adicionado `request.resource.data.tenantId == userTenant()` |
| VULN-08 | 🟡 MÉDIO | `nexia-master-admin.html` | String corrompida em `EXTERNAL_PAGES.scanner` | Corrigida para `'pki-scanner.html'` |
| VULN-09 | 🟡 MÉDIO | `nexia-master-admin.html` + `audit-log.js` | Frontend escrevia em `audit_log_global` (create:false nas Rules) — logs perdidos silenciosamente | Criado endpoint `/api/audit` com Admin SDK |
| BÓNUS-01 | 🟡 MÉDIO | `firestore.rules` | `kill_switch` read público | Alterado para `isAuth() && isMember()` |
| BÓNUS-02 | 🟡 MÉDIO | `payment-engine.js` | CORS `*` como fallback | Alterado para URL real do projeto |
| BÓNUS-03 | 🟡 MÉDIO | `firestore.rules` | `event_queue`, `cortex_jobs`, `store_orders` create sem isolamento | Adicionadas verificações de `tenantId`/`userId` |

---

## ✅ SESSÃO 2 — Pendentes P4–P6 (3 fixes)

| ID | Sev | Ficheiro | Problema | Fix |
|----|-----|----------|----------|-----|
| P6 | 🟡 MÉDIO | `nexia-master-admin.html` | `salvarAgente()`/`publicarModulo()` com `getElementById` a retornar `null` — falha silenciosa | Adicionados `id="ag-nome"`, `id="ag-tipo"`, `id="ag-prompt"`, `id="mod-nome"`, `id="mod-preco"`, `id="mod-desc"` |
| P5 | 🟢 BAIXO | `qa-test-center.html` | `/api/audit` não testado no QA Center | Adicionado `{path:'/api/audit', method:'POST', auth:true, ...}` ao array `APIS` |
| P4 | 🟡 MÉDIO | `vp-passenger.html` + `vp-guide.html` | Auth verificada mas role não validado — qualquer user autenticado acedia às páginas | Adicionado `_vpPassengerGuard()` e `_vpGuideGuard()` com `onAuthStateChanged` + verificação de role no Firestore; redireciona para login ou bloqueia com mensagem de erro |

---

## ✅ SESSÃO 3 — Pendentes P1–P3 (3 fixes)

| ID | Sev | Ficheiro | Problema | Fix |
|----|-----|----------|----------|-----|
| P3 | 🟡 MÉDIO | `netlify/functions/auth.js` | Sem rate limiting no endpoint `/api/auth` — vulnerável a brute-force/enumeração | Adicionado `_checkAuthRateLimit()` por IP: 20 tentativas / 15 min; retorna 429 com `retryAfter` |
| P2 | 🟡 MÉDIO | `netlify.toml` | CSP com `unsafe-eval` activo — permitia `eval()` no browser | Auditado todo o codebase (0 usos de `eval()`/`new Function()`); `unsafe-eval` removido do header CSP |
| P1 | 🟢 BAIXO | `.env.example` (novo) | Sem template de variáveis de ambiente documentado | Criado `.env.example` com 36 variáveis, agrupadas e comentadas em PT-BR |

---

## 📊 Resumo Total

| Criticidade | Qtd | Estado |
|-------------|-----|--------|
| 🔴 Crítico | 3 | ✅ Todos corrigidos |
| 🟠 Alto | 3 | ✅ Todos corrigidos |
| 🟡 Médio | 10 | ✅ Todos corrigidos |
| 🟢 Baixo | 2 | ✅ Todos corrigidos |
| **TOTAL** | **18** | ✅ **100% concluído** |

---

## 🗂️ Ficheiros Modificados / Criados (v41)

```
nexia_v40_FIXED/
├── .env.example                          ← NOVO (P1) — 36 vars documentadas
├── netlify.toml                          ← P2 — unsafe-eval removido do CSP
│                                            + /api/audit redirect (sessão 1)
├── core/
│   └── auth.js                          ← VULN-02 — tenantSlug:'guest'
├── firestore.rules                       ← VULN-07 + BÓNUS-01/03
├── netlify/functions/
│   ├── audit-log.js                     ← NOVO (VULN-09) — endpoint seguro
│   ├── auth.js                          ← P3 — rate limit por IP (20/15min)
│   ├── churn-predictor.js              ← VULN-01 — await guard()
│   ├── dunning-scheduler.js            ← VULN-04/05 — idempotência + secret
│   ├── kpi-engine.js                   ← VULN-01 — await guard()
│   ├── middleware.js                   ← VULN-03 — fail-closed
│   ├── payment-engine.js              ← BÓNUS-02 — CORS restrito
│   └── whatsapp-business.js           ← VULN-06 — HMAC obrigatório
├── nexia/
│   ├── nexia-master-admin.html         ← VULN-08/09 + P6 (IDs modais)
│   └── qa-test-center.html             ← P5 — /api/audit adicionado
└── viajante-pro/
    ├── vp-passenger.html               ← P4 — _vpPassengerGuard()
    └── vp-guide.html                   ← P4 — _vpGuideGuard()
```

---

## 🧪 Smoke Tests Pós-Deploy (manual)

### Autenticação e Autorização
- [ ] Login com conta não-master → confirmar redirect para `/nexia/tenant-hub.html`
- [ ] Criar conta nova via Firebase → `tenantSlug` deve ser `'guest'`, não `'nexia'`
- [ ] Aceder `/api/churn` sem token → deve retornar **401**
- [ ] Aceder `/api/kpi` sem token → deve retornar **401**
- [ ] Enviar 21 POST para `/api/auth` no mesmo IP → 21.º deve retornar **429**

### Dunning
- [ ] Disparar dunning 2x no mesmo dia → deve processar apenas uma vez

### WhatsApp
- [ ] Webhook WhatsApp sem `X-Hub-Signature-256` → deve retornar **401**

### Viajante Pro
- [ ] Aceder `vp-passenger.html` sem login → redirect para `/login.html`
- [ ] Aceder `vp-passenger.html` com user role=`'admin'` (não passenger) → mensagem "Acesso Negado"
- [ ] Aceder `vp-guide.html` com user role=`'passenger'` → mensagem "Acesso Negado"

### CSP
- [ ] Abrir DevTools → Console → verificar ausência de erros CSP
- [ ] Confirmar que `unsafe-eval` não aparece no header `Content-Security-Policy`

### Audit Log
- [ ] Acção no painel master → verificar que registo aparece em `audit_log_global` no Firestore (via Admin SDK)

### QA Test Center
- [ ] Correr suite completa em `/nexia/qa-test-center.html` → `/api/audit` deve aparecer e passar

---

## 🔑 Variáveis Obrigatórias para Produção

Mínimo necessário para deploy funcional:

```bash
FIREBASE_SERVICE_ACCOUNT_BASE64=...   # ou FIREBASE_SERVICE_ACCOUNT
NEXIA_APP_URL=https://seudominio.netlify.app
NEXIA_EMAIL_DOMAIN=seudominio.com
GROQ_API_KEY=gsk_...
ANTHROPIC_API_KEY=sk-ant-...
MP_ACCESS_TOKEN=APP_USR-...
META_APP_SECRET=...                   # OBRIGATÓRIO — HMAC WhatsApp
DUNNING_SECRET=...                    # OBRIGATÓRIO — gerar com openssl rand -hex 32
RESEND_API_KEY=re_...
```

Ver `.env.example` para lista completa das 36 variáveis.

---

## ⚠️ Notas para Próximo Engenheiro

1. **`unsafe-eval` removido** — Se alguma lib futura precisar de `eval()`, documentar aqui antes de re-adicionar ao CSP.
2. **Rate limit de auth é in-memory** — Reinicia em cada cold start do Netlify. Para produção de alta escala, mover `_authRLMap` para Redis ou Firestore.
3. **Role check em vp-passenger/vp-guide** — O role é lido do documento `users/{uid}` no Firestore. Garantir que o campo `role` ou `tenantRole` é preenchido corretamente no registo.
4. **`FIREBASE_SERVICE_ACCOUNT_BASE64` vs `FIREBASE_SERVICE_ACCOUNT`** — O código suporta ambos. Usar BASE64 no Netlify para evitar problemas de parsing com aspas.
