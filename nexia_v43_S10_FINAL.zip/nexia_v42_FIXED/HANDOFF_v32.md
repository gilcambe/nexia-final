# NEXIA OS — HANDOFF v32
**Data:** 30/03/2026  
**Arquivo:** `nexia_v32_PRODUCAO.zip`  
**Status:** ✅ PRODUÇÃO — 4 bugs corrigidos em `vp-admin.html`

---

## Correções aplicadas nesta versão

### 1. `const anthropicKey` duplicado (Bug crítico)
**Arquivo:** `viajante-pro/vp-admin.html`  
**Problema:** Havia `const anthropicKey = null` na linha 677 e `let anthropicKey = ''` na linha 685 — erro de sintaxe que quebrava o JavaScript inteiro no modo estrito.  
**Correção:** Removida a declaração duplicada. A variável agora é apenas um comentário explicativo de que a chave fica no servidor via `/api/cortex`.

### 2. `m-roteiro` → `m-novo-roteiro` (Bug de referência)
**Arquivo:** `viajante-pro/vp-admin.html`  
**Problema:** Função `editarRoteiro()` chamava `document.getElementById('m-roteiro')` — modal inexistente (o correto é `m-novo-roteiro`). O botão de editar nunca abria.  
**Correção:** Substituído para `document.getElementById('m-novo-roteiro').classList.add('show')`.

### 3. `perfilPax()` buscava em `leadsData` (Bug lógico)
**Arquivo:** `viajante-pro/vp-admin.html`  
**Problema:** A função `perfilPax()` fazia `leadsData.find(x => x.id === id)` em vez de `paxData.find()`. Passageiros nunca eram encontrados no perfil.  
**Correção:** Substituído para `paxData.find()` e campos ajustados para os campos reais do modelo de passageiro (`nome`, `email`, `wpp`, `doc`, `viagens`, `ultima`, `status`).

### 4. `dropPax()` inexistente + modal `#m-novo-pax` + `salvarPax()` ausentes (Bug de funcionalidade)
**Arquivo:** `viajante-pro/vp-admin.html`  
**Problemas:**
- `ondrop="dropPax(event,'sem')"` na zona "Sem Quarto" chamava função não definida → erro JS
- Botão "Novo PAX" chamava `om('m-novo-pax')` → modal não existia
- `salvarPax()` não estava implementada

**Correções:**
- Adicionada função `dropPax(event, zone)` que funciona como alias de `roomDrop` para a zona "sem quarto", permitindo arrastar passageiros de volta para fora dos quartos
- Adicionado modal `#m-novo-pax` com form completo: nome, email, WhatsApp, documento, data de nascimento, status, observações
- Implementada `salvarPax()` com persistência no Firestore e fallback local

---

## Estrutura do projeto

```
nexia_FINAL/
├── core/               # Config Firebase, auth, nexia-engine
├── netlify/functions/  # Funções serverless (cortex, payment, whatsapp, etc.)
├── splash/
│   ├── splash-admin.html   ✅ v15 (let EVENTS, saveSettings Firestore)
│   └── splash-landing.html
├── ces/
│   ├── ces-admin.html      ✅ v11 (saveSettings Firestore, genMatches Firestore)
│   └── ces-landing.html
├── viajante-pro/
│   ├── vp-admin.html       ✅ v32 (4 bugs corrigidos — veja acima)
│   └── vp-landing.html
├── bezsan/
│   ├── bezsan-admin.html   ✅ (saveSettings Firestore)
│   └── bezsan-landing.html
├── nexia/
│   ├── nexia-master-admin.html
│   └── ...outros módulos
├── netlify.toml        ✅ SPA fallback no final, sem duplicatas
├── firebase.json
└── firestore.rules
```

---

## Próximos passos sugeridos

1. **Deploy no Netlify** — fazer push para o repositório GitHub conectado ao Netlify
2. **Testar vp-admin.html** — especialmente o Rooming List drag & drop e o modal Novo PAX
3. **Configurar variáveis de ambiente no Netlify:**
   - `ANTHROPIC_API_KEY` — chave da API Anthropic para o CORTEX
   - `MP_ACCESS_TOKEN` — Mercado Pago
   - `WHATSAPP_TOKEN` — WhatsApp Business API
4. **Seed Firebase** — rodar `seed-firebase.js` para dados iniciais de teste

---

## Estado de saúde do projeto

| Arquivo | Status | Última correção |
|---------|--------|----------------|
| `splash-admin.html` | ✅ OK | v15 — let EVENTS, saveSettings |
| `ces-admin.html` | ✅ OK | v11 — saveSettings, genMatches |
| `vp-admin.html` | ✅ OK | **v32 — 4 bugs corrigidos** |
| `bezsan-admin.html` | ✅ OK | saveSettings Firestore |
| `netlify.toml` | ✅ OK | SPA fallback no final |
| `/api/cortex` | ✅ OK | Anthropic claude-sonnet-4-20250514 |
| `/api/payment` | ✅ OK | Mercado Pago split |
| `/api/whatsapp` | ✅ OK | WhatsApp Business |
